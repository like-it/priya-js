this is the production version

the development version is in Priya/Module/Javascript/Public/Js/Priya.js